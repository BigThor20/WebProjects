var sliders = {
    "mainSlider": [
        {
            texts: {
                heading: "Victor - frontend developer",
                statement: "Creativitate, implicare, inovatie si profesionalism."

            }
        }, {
            texts: {
                heading: "Artist digital",
                statement: "Solutii creative pentru proiectul tau."
            }
        }, {
            texts: {
                heading: "Design unic",
                statement: "Cheia succesului in mediul online."
            }
        }
    ]
};